//
//  ViewController.swift
//  CoreDataMemo
//
//  Created by 문주원 on 2020/10/26.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

